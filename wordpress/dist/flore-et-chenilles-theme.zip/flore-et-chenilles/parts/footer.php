<?php
/* Généré par tools/wordpress/build.js à partir de index.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
?>
<footer class="site-footer">
    <div class="container footer-grid">
      <div class="footer-brand">
        <a class="logo" href="<?php echo fc_home_anchor(); ?>#accueil" aria-label="Flore &amp; Chenilles, retour en haut">
          <img class="logo-img logo-img--lg" src="<?php echo esc_url( FC_ASSETS ); ?>assets/photos/logo.jpg" alt="" width="64" height="64">
          <span class="logo-word">Flore <em>&amp;</em> Chenilles</span>
        </a>
        <p>Bouquets et décorations en fleurs éternelles, façonnés à la main avec passion dans mon atelier de <span data-city>Signy-l’Abbaye</span>, dans les Ardennes.</p>
      </div>
      <nav class="footer-nav" aria-label="Plan du site">
        <h3>Explorer</h3>
        <a href="<?php echo fc_home_anchor(); ?>#atelier">L’atelier</a>
        <a href="<?php echo fc_home_anchor(); ?>#boutique">Mes créations</a>
        <a href="<?php echo fc_home_anchor(); ?>#bouquet">Votre bouquet à vous</a>
        <a href="<?php echo fc_home_anchor(); ?>#occasions">Occasions</a>
        <a href="<?php echo fc_home_anchor(); ?>#livraison">Livraison &amp; retrait</a>
        <a href="<?php echo fc_home_anchor(); ?>#faq">Questions fréquentes</a>
      </nav>
      <div class="footer-nav">
        <h3>Restons en lien</h3>
        <a data-ig href="<?php echo esc_url( fc_instagram_url() ); ?>" target="_blank" rel="noopener">Instagram</a>
        <a data-fb hidden href="<?php echo fc_home_anchor(); ?>#contact" target="_blank" rel="noopener">Facebook</a>
        <a data-ig-dm href="https://ig.me/m/<?php echo rawurlencode( fc_setting( 'instagram', 'flore_et_chenilles' ) ); ?>" target="_blank" rel="noopener">Message privé</a>
        <a href="<?php echo fc_home_anchor(); ?>#contact">Formulaire de contact</a>
        <a data-email <?php fc_email_attrs(); ?> data-email-row><?php echo fc_email_text(); // phpcs:ignore ?></a>
      </div>
    </div>
    <p class="footer-big" aria-hidden="true">Flore <em>&amp;</em> Chenilles</p>
    <div class="container footer-bottom">
      <p>© <span data-year><?php echo esc_html( wp_date( 'Y' ) ); ?></span> Flore &amp; Chenilles — Fait main avec passion dans les Ardennes</p>
      <?php fc_legal_links(); ?>
      <a href="<?php echo is_front_page() ? '#accueil' : '#main'; ?>" class="to-top">Retour en haut <svg><use href="<?php echo fc_home_anchor(); ?>#i-arrow"/></svg></a>
    </div>
  </footer>
