<?php
/* Généré par tools/wordpress/build.js à partir de index.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
?>
<header class="site-header">
    <div class="container header-inner">
      <a class="logo" href="<?php echo fc_home_anchor(); ?>#accueil" aria-label="Flore &amp; Chenilles, retour à l’accueil">
        <img class="logo-img" src="<?php echo esc_url( FC_ASSETS ); ?>assets/photos/logo.jpg" alt="" width="44" height="44">
        <span class="logo-word">Flore <em>&amp;</em> Chenilles</span>
      </a>
      <nav class="nav" aria-label="Navigation principale">
        <a href="<?php echo fc_home_anchor(); ?>#atelier">L’atelier</a>
        <a href="<?php echo fc_home_anchor(); ?>#boutique">Créations</a>
        <a href="<?php echo fc_home_anchor(); ?>#bouquet">Votre bouquet</a>
        <a href="<?php echo fc_home_anchor(); ?>#occasions">Occasions</a>
        <a href="<?php echo fc_home_anchor(); ?>#contact">Contact</a>
      </nav>
      <div class="header-actions">
        <a class="icon-btn hide-sm" data-ig href="<?php echo esc_url( fc_instagram_url() ); ?>" target="_blank" rel="noopener" aria-label="Instagram de Flore &amp; Chenilles (nouvel onglet)"><svg><use href="<?php echo fc_home_anchor(); ?>#i-instagram"/></svg></a>
        <a class="icon-btn hide-sm" data-fb hidden href="<?php echo fc_home_anchor(); ?>#contact" target="_blank" rel="noopener" aria-label="Facebook de Flore &amp; Chenilles (nouvel onglet)"><svg><use href="<?php echo fc_home_anchor(); ?>#i-facebook"/></svg></a>
        <?php fc_cart_button(); ?>
        <button class="icon-btn burger" type="button" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="mobile-menu"><span></span><span></span></button>
      </div>
    </div>
    <div class="crawl" aria-hidden="true"><div class="crawl-bar"></div><div class="crawl-bug" data-caterpillar></div></div>
  </header>

<div class="mobile-menu" id="mobile-menu" aria-hidden="true">
    <nav aria-label="Menu mobile">
      <a href="<?php echo fc_home_anchor(); ?>#atelier" style="--i:0">L’atelier</a>
      <a href="<?php echo fc_home_anchor(); ?>#boutique" style="--i:1">Créations</a>
      <a href="<?php echo fc_home_anchor(); ?>#bouquet" style="--i:2">Votre bouquet</a>
      <a href="<?php echo fc_home_anchor(); ?>#occasions" style="--i:3">Occasions</a>
      <a href="<?php echo fc_home_anchor(); ?>#livraison" style="--i:4">Livraison</a>
      <a href="<?php echo fc_home_anchor(); ?>#contact" style="--i:5">Contact</a>
    </nav>
    <div class="mobile-social">
      <a class="btn btn-ghost" data-ig href="<?php echo esc_url( fc_instagram_url() ); ?>" target="_blank" rel="noopener"><svg><use href="<?php echo fc_home_anchor(); ?>#i-instagram"/></svg><span data-ig-handle>@<?php echo esc_html( fc_setting( 'instagram', 'flore_et_chenilles' ) ); ?></span></a>
      <a class="btn btn-ghost" data-fb hidden href="<?php echo fc_home_anchor(); ?>#contact" target="_blank" rel="noopener"><svg><use href="<?php echo fc_home_anchor(); ?>#i-facebook"/></svg><span>Facebook</span></a>
    </div>
  </div>
