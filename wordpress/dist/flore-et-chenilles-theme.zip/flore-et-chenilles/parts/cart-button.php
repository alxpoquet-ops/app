<?php
/* Généré par tools/wordpress/build.js à partir de index.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
?>
<button class="icon-btn cart-btn" type="button" data-open-cart aria-label="Ouvrir ma sélection">
          <svg><use href="#i-bag"/></svg><span class="cart-count" data-cart-count>0</span>
        </button>
