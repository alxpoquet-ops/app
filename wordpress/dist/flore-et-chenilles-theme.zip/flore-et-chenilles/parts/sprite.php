<?php
/* Généré par tools/wordpress/build.js à partir de index.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
?>
<svg class="sprite" aria-hidden="true" focusable="false">
    <defs>
      <filter id="fc-fuzz" x="-10%" y="-10%" width="120%" height="120%" color-interpolation-filters="sRGB">
        <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed="7" result="n"/>
        <feDisplacementMap in="SourceGraphic" in2="n" scale="2.6" xChannelSelector="R" yChannelSelector="G"/>
      </filter>
      <symbol id="i-bag" viewBox="0 0 24 24"><path d="M5.5 8h13l-1.1 11.2a1.5 1.5 0 0 1-1.5 1.3H8.1a1.5 1.5 0 0 1-1.5-1.3L5.5 8z"/><path d="M9 10V6.8a3 3 0 0 1 6 0V10"/></symbol>
      <symbol id="i-instagram" viewBox="0 0 24 24"><rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r=".6" fill="currentColor"/></symbol>
      <symbol id="i-arrow" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></symbol>
      <symbol id="i-close" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></symbol>
      <symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
      <symbol id="i-hand" viewBox="0 0 24 24"><path d="M8 13V6.5a1.5 1.5 0 0 1 3 0V12m0-6.5V5a1.5 1.5 0 0 1 3 0v7m0-5.5a1.5 1.5 0 0 1 3 0V14c0 3.9-2.7 7-6.5 7-2.6 0-4.2-1.3-5.6-3.4L4.2 15a1.6 1.6 0 0 1 2.6-1.8L8 15"/></symbol>
      <symbol id="i-infinity" viewBox="0 0 24 24"><path d="M12 12c-1.8-2.2-3-3.5-5-3.5a3.5 3.5 0 0 0 0 7c2 0 3.2-1.3 5-3.5zm0 0c1.8 2.2 3 3.5 5 3.5a3.5 3.5 0 0 0 0-7c-2 0-3.2 1.3-5 3.5z"/></symbol>
      <symbol id="i-sparkle" viewBox="0 0 24 24"><path d="M11 3.5l1.7 4.8 4.8 1.7-4.8 1.7L11 16.5l-1.7-4.8L4.5 10l4.8-1.7z"/><path d="M18 14.5l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/></symbol>
      <symbol id="i-leaf" viewBox="0 0 24 24"><path d="M5 19c0-8 5-13.5 14-14 0 9-5.5 14-14 14z"/><path d="M5 19l8.5-8.5"/></symbol>
      <symbol id="i-palette" viewBox="0 0 24 24"><path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.2 0 1.8-.8 1.8-1.7 0-1.2-1-1.5-1-2.6 0-1 .8-1.7 1.8-1.7h2.2a3.7 3.7 0 0 0 3.7-3.7C20.5 6.9 16.7 3.5 12 3.5z"/><circle cx="7.8" cy="11.5" r="1"/><circle cx="10" cy="7.6" r="1"/><circle cx="14.6" cy="7.6" r="1"/></symbol>
      <symbol id="i-gift" viewBox="0 0 24 24"><rect x="4" y="9" width="16" height="11" rx="1.5"/><path d="M3 9h18M12 9v11M12 9c-1.5-3.5-6-4-6-1.5S10 9 12 9zm0 0c1.5-3.5 6-4 6-1.5S14 9 12 9z"/></symbol>
      <symbol id="i-mail" viewBox="0 0 24 24"><rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><path d="M4 7.5l8 5.5 8-5.5"/></symbol>
      <symbol id="i-chat" viewBox="0 0 24 24"><path d="M20 11.5a8 8 0 0 1-11.6 7.1L4 19.8l1.2-4.1A8 8 0 1 1 20 11.5z"/></symbol>
      <symbol id="i-link" viewBox="0 0 24 24"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></symbol>
      <symbol id="i-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8h.01"/></symbol>
      <symbol id="i-check" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></symbol>
      <symbol id="i-undo" viewBox="0 0 24 24"><path d="M9 7L5 11l4 4"/><path d="M5 11h9a5 5 0 0 1 0 10h-2"/></symbol>
      <symbol id="i-refresh" viewBox="0 0 24 24"><path d="M19 12a7 7 0 1 1-2.1-5"/><path d="M19 4v4h-4"/></symbol>
      <symbol id="i-pin" viewBox="0 0 24 24"><path d="M12 21s-6.5-6-6.5-11a6.5 6.5 0 0 1 13 0c0 5-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/></symbol>
      <symbol id="i-flower" viewBox="0 0 24 24"><g fill="currentColor" stroke="none"><circle cx="12" cy="6.6" r="3.4"/><circle cx="17.1" cy="10.4" r="3.4"/><circle cx="15.2" cy="16.4" r="3.4"/><circle cx="8.8" cy="16.4" r="3.4"/><circle cx="6.9" cy="10.4" r="3.4"/></g><circle cx="12" cy="12" r="2.4" fill="#FFF6E2" stroke="none"/></symbol>
      <symbol id="i-heart" viewBox="0 0 24 24"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></symbol>
      <symbol id="i-logo" viewBox="-30 -30 60 60">
        <g filter="url(#fc-fuzz)">
          <path d="M0 -3C-9.5 -7 -9 -24 0 -25C9 -24 9.5 -7 0 -3Z" fill="#F3C4CF" stroke="#E3A0B3" stroke-width="2"/>
          <path d="M0 -3C-9.5 -7 -9 -24 0 -25C9 -24 9.5 -7 0 -3Z" fill="#D9CBF0" stroke="#B9A6E2" stroke-width="2" transform="rotate(72)"/>
          <path d="M0 -3C-9.5 -7 -9 -24 0 -25C9 -24 9.5 -7 0 -3Z" fill="#F8CDB5" stroke="#EBA88A" stroke-width="2" transform="rotate(144)"/>
          <path d="M0 -3C-9.5 -7 -9 -24 0 -25C9 -24 9.5 -7 0 -3Z" fill="#C6E6D3" stroke="#98CBAE" stroke-width="2" transform="rotate(216)"/>
          <path d="M0 -3C-9.5 -7 -9 -24 0 -25C9 -24 9.5 -7 0 -3Z" fill="#C9DDF2" stroke="#9DBFE4" stroke-width="2" transform="rotate(288)"/>
          <circle r="6" fill="#F5D58C" stroke="#E2B65F" stroke-width="1.8"/>
        </g>
      </symbol>
      <symbol id="i-facebook" viewBox="0 0 24 24"><path fill="currentColor" stroke="none" d="M13.6 21v-7.2h2.4l.4-2.9h-2.8V9.1c0-.8.3-1.4 1.4-1.4h1.5V5.1c-.3 0-1.2-.1-2.2-.1-2.2 0-3.6 1.3-3.6 3.7v2.2H8.3v2.9h2.4V21z"/></symbol>
      <symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></symbol>
      <symbol id="i-drop" viewBox="0 0 24 24"><path d="M12 3.5C9 8 6.5 10.8 6.5 14a5.5 5.5 0 0 0 11 0c0-3.2-2.5-6-5.5-10.5z"/><path d="M9.6 14.6a2.5 2.5 0 0 0 2 2.3"/></symbol>
      <symbol id="i-photos" viewBox="0 0 24 24"><rect x="3.5" y="6.5" width="13" height="13" rx="2.5"/><path d="M7.5 3.5h10a3 3 0 0 1 3 3v10"/><path d="M4 16l3.5-3.5 3 3 2-2 3.5 3.5"/></symbol>
      <symbol id="i-truck" viewBox="0 0 24 24"><path d="M3.5 6.5h10v10h-10zM13.5 10h4l3 3.2v3.3h-7"/><circle cx="7.5" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/></symbol>
      <symbol id="i-stem" viewBox="0 0 24 24"><path d="M12 21.5V9"/><path d="M12 9c0-3 1.8-5.2 4.6-5.6"/><path d="M12 15.5c-3 .1-5.2-1.6-5.8-4.4 3-.1 5.2 1.6 5.8 4.4z"/></symbol>
      <symbol id="i-tape" viewBox="0 0 24 24"><circle cx="10" cy="11" r="6.5"/><circle cx="10" cy="11" r="2.4"/><path d="M16.5 11v7.5h4.5"/></symbol>
      <symbol id="i-brush" viewBox="0 0 24 24"><path d="M4.5 19.5l7.2-7.2"/><path d="M11.2 12.8l1.9-1.9 2.6 2.6-1.9 1.9z"/><path d="M13.6 10.4c1-3.1 3.6-5.7 6.9-6.9-1.1 3.3-3.7 5.9-6.9 6.9z"/></symbol>
      <symbol id="i-jar" viewBox="0 0 24 24"><path d="M8.5 3.5h7M9.5 3.5v2.4L7.4 8A3.2 3.2 0 0 0 6.5 10.2V18a2.5 2.5 0 0 0 2.5 2.5h6a2.5 2.5 0 0 0 2.5-2.5v-7.8a3.2 3.2 0 0 0-.9-2.2l-2.1-2.1V3.5"/><path d="M9.5 13.5c1.6-1.1 3.4-1.1 5 0"/></symbol>
      <symbol id="i-chenille" viewBox="0 0 34 18"><g fill="currentColor" stroke="none"><circle cx="4.5" cy="12" r="3.3"/><circle cx="11" cy="11" r="3.7"/><circle cx="18" cy="12" r="3.9"/><circle cx="26" cy="10" r="4.8"/></g><path d="M24.5 5.4Q23 2 20.6 1.6M27.6 5Q29 1.6 31.4 1.4" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></symbol>
    </defs>
  </svg>
