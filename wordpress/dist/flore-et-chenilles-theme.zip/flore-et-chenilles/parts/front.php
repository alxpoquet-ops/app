<?php
/* Généré par tools/wordpress/build.js à partir de index.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
?>
<main id="main">
    <!-- ============================== ACCUEIL ============================== -->
    <section class="hero" id="accueil">
      <div class="hero-bg" aria-hidden="true"><span class="blob b1"></span><span class="blob b2"></span><span class="blob b3"></span></div>
      <div class="container hero-grid">
        <div class="hero-copy">
          <a class="promo-pill" href="#boutique" data-promo-pill hidden></a>
          <p class="eyebrow reveal">Fleurs éternelles en fil chenille · Ardennes</p>
          <h1 class="display reveal" style="--i:1">Des fleurs tout en douceur, <em>qui ne fanent jamais.</em></h1>
          <p class="lead reveal" style="--i:2">Bouquets et décorations en fleurs éternelles, façonnés à la main dans mon atelier des Ardennes. Des créations sur-mesure pour tous vos évènements et vos cadeaux… ou juste pour le plaisir.</p>
          <div class="hero-cta reveal" style="--i:3">
            <a class="btn btn-primary" href="#boutique">Voir mes créations <svg><use href="#i-arrow"/></svg></a>
            <a class="btn btn-ghost" href="#bouquet"><svg><use href="#i-sparkle"/></svg> Composer mon bouquet</a>
          </div>
          <ul class="hero-points reveal" style="--i:4">
            <li><svg><use href="#i-hand"/></svg> Tout à la main</li>
            <li><svg><use href="#i-infinity"/></svg> Ne fane jamais</li>
            <li><svg><use href="#i-palette"/></svg> Sur-mesure</li>
          </ul>
        </div>

        <div class="hero-art">
          <div class="arch arch--photo">
            <button class="hero-slides" type="button" data-hero-slides aria-label="Voir cette création"></button>
            <div class="hero-dots" data-hero-dots aria-label="Choisir une photo"></div>
          </div>
          <div class="badge-rotate" aria-hidden="true">
            <svg class="ring" viewBox="0 0 120 120">
              <defs><path id="ring-path" d="M60 60m-43 0a43 43 0 1 1 86 0a43 43 0 1 1-86 0"/></defs>
              <circle cx="60" cy="60" r="58" fill="#FFFAF6"/>
              <circle cx="60" cy="60" r="55" fill="none" stroke="#EBD9DE" stroke-dasharray="1 4" stroke-linecap="round"/>
              <text font-family="Jost, sans-serif" font-size="9.6" font-weight="500" fill="#6B5262"><textPath href="#ring-path" textLength="268" lengthAdjust="spacing">FAIT MAIN · AVEC PASSION · DANS LES ARDENNES ·</textPath></text>
            </svg>
            <img class="badge-core" src="<?php echo esc_url( FC_ASSETS ); ?>assets/photos/logo.jpg" alt="">
          </div>
          <button class="hero-chip" type="button" data-featured>
            <span class="hero-chip-art" data-featured-art></span>
            <span class="hero-chip-txt"><small>Nouveauté</small><strong data-featured-name>Bonsaï azalée</strong></span>
            <svg class="hero-chip-arrow"><use href="#i-arrow"/></svg>
          </button>
          <div class="butterfly bf1" data-butterfly="#C8A0E2" aria-hidden="true"></div>
          <div class="butterfly bf2" data-butterfly="#F5B07D" aria-hidden="true"></div>
          <div class="butterfly bf3" data-butterfly="#F4ADC5" aria-hidden="true"></div>
        </div>
      </div>
      <a class="scroll-hint" href="#atelier" aria-label="Faire défiler vers l’atelier"><span></span></a>
    </section>

    <div class="marquee-wrap">
      <div class="marquee" aria-hidden="true">
        <div class="marquee-track">
          <span>Fait main avec passion</span><svg><use href="#i-flower"/></svg>
          <span>Fleurs éternelles</span><svg><use href="#i-flower"/></svg>
          <span>Sans pollen</span><svg><use href="#i-flower"/></svg>
          <span>Fils de qualité</span><svg><use href="#i-flower"/></svg>
          <span>Carte de vœux offerte</span><svg><use href="#i-flower"/></svg>
          <span>Créations sur-mesure</span><svg><use href="#i-flower"/></svg>
          <span>Évènements &amp; cadeaux</span><svg><use href="#i-flower"/></svg>
          <span>Atelier des Ardennes</span><svg><use href="#i-flower"/></svg>
          <span>Fait main avec passion</span><svg><use href="#i-flower"/></svg>
          <span>Fleurs éternelles</span><svg><use href="#i-flower"/></svg>
          <span>Sans pollen</span><svg><use href="#i-flower"/></svg>
          <span>Fils de qualité</span><svg><use href="#i-flower"/></svg>
          <span>Carte de vœux offerte</span><svg><use href="#i-flower"/></svg>
          <span>Créations sur-mesure</span><svg><use href="#i-flower"/></svg>
          <span>Évènements &amp; cadeaux</span><svg><use href="#i-flower"/></svg>
          <span>Atelier des Ardennes</span><svg><use href="#i-flower"/></svg>
        </div>
      </div>
    </div>

    <!-- ============================== L'ATELIER ============================== -->
    <section class="section about" id="atelier" aria-labelledby="about-title">
      <div class="container about-grid">
        <div class="about-art reveal">
          <div class="arch arch--photo"><img class="arch-img" src="<?php echo esc_url( FC_ASSETS ); ?>assets/photos/about.jpg" alt="Détail du bouquet Améthyste : lys, pavots et hortensias en fil chenille" loading="lazy"></div>
          <div class="sticker"><span>Fait main dans les Ardennes</span></div>
        </div>
        <div class="about-copy">
          <p class="eyebrow reveal">L’atelier</p>
          <h2 id="about-title" class="reveal" style="--i:1">Fait main dans les Ardennes, <em>avec passion</em></h2>
          <p class="reveal" style="--i:2">Flore &amp; Chenilles, c’est mon atelier à <span data-city>Signy-l’Abbaye</span>, dans les Ardennes. C’est là que je façonne, avec passion, des bouquets et des décorations en fleurs éternelles&nbsp;: lys, arums, pavots, gerberas, tulipes, hortensias, tournesols…</p>
          <p class="reveal" style="--i:3">Tout est fait à la main, fleur après fleur. Je sélectionne mes fils chenille pour leur qualité et leur durabilité, pour que chaque création garde ses couleurs et sa douceur, année après année.</p>
          <p class="reveal" style="--i:4">J’imagine aussi des créations sur-mesure pour vos évènements et vos cadeaux, et j’aime chiner en brocante de jolis contenants à fleurir.</p>
          <p class="signature reveal" style="--i:5">Avec douceur, <span>Flore &amp; Chenilles</span> <svg class="sig-chenille" aria-hidden="true"><use href="#i-chenille"/></svg></p>
          <div class="values">
            <article class="value reveal" style="--i:0;--tint:#F8E1E6"><span class="value-ic"><svg><use href="#i-hand"/></svg></span><h3>Tout à la main</h3><p>Chaque fleur est pliée, torsadée et ajustée à la main, dans mon atelier.</p></article>
            <article class="value reveal" style="--i:1;--tint:#ECE5F8"><span class="value-ic"><svg><use href="#i-sparkle"/></svg></span><h3>Fils sélectionnés</h3><p>Choisis pour leur qualité et leur durabilité, pour des couleurs qui tiennent.</p></article>
            <article class="value reveal" style="--i:2;--tint:#E2F1E7"><span class="value-ic"><svg><use href="#i-infinity"/></svg></span><h3>Éternelles</h3><p>Ni eau ni entretien, et sans pollen&nbsp;: idéal pour les allergiques et les chambres d’enfants.</p></article>
            <article class="value reveal" style="--i:3;--tint:#FBEBDD"><span class="value-ic"><svg><use href="#i-palette"/></svg></span><h3>Sur-mesure</h3><p>Vos couleurs, vos fleurs, votre occasion&nbsp;: un bouquet à votre image.</p></article>
          </div>
        </div>
      </div>
    </section>

    <!-- ============================== ÉTAPES ============================== -->
    <section class="section steps" aria-labelledby="steps-title">
      <div class="container">
        <div class="section-head center">
          <p class="eyebrow reveal">Comment ça se passe&#8239;?</p>
          <h2 id="steps-title" class="reveal" style="--i:1">De votre idée <em>à votre bouquet</em></h2>
        </div>
        <ol class="steps-list">
          <li class="step reveal" style="--i:0;--tint:#F8E1E6"><span class="step-n">1</span><h3>Vous choisissez</h3><p>Une de mes créations, ou votre propre bouquet, fleur par fleur.</p></li>
          <li class="step reveal" style="--i:1;--tint:#ECE5F8"><span class="step-n">2</span><h3>Je vous réponds</h3><p>Je confirme avec vous les couleurs, le prix et la date par e-mail.</p></li>
          <li class="step reveal" style="--i:2;--tint:#E2F1E7"><span class="step-n">3</span><h3>Je façonne</h3><p>Votre création prend vie à la main, dans mon atelier des Ardennes.</p></li>
          <li class="step reveal" style="--i:3;--tint:#FBEBDD"><span class="step-n">4</span><h3>Vous la recevez</h3><p>Retrait à l’atelier ou livraison autour de Signy-l’Abbaye.</p></li>
        </ol>
      </div>
    </section>

    <!-- ============================== CRÉATIONS ============================== -->
    <section class="section shop" id="boutique" aria-labelledby="shop-title">
      <div class="container">
        <div class="section-head split">
          <div>
            <p class="eyebrow reveal">Mes créations</p>
            <h2 id="shop-title" class="reveal" style="--i:1">Prêtes à être <em>adoptées</em></h2>
          </div>
          <p class="section-sub reveal" style="--i:2">Chaque création est faite à la main, sur commande, et emballée dans une pochette transparente fermée d’un nœud, avec sa carte de vœux offerte.</p>
        </div>
        <div class="promo-banner" data-promo-banner hidden></div>
        <div class="shop-tools reveal">
          <div class="filters" role="group" aria-label="Filtrer les créations" data-filters></div>
          <label class="sort-field" for="shop-sort"><span>Trier</span>
            <select id="shop-sort" data-sort>
              <option value="">Mes coups de cœur</option>
              <option value="asc">Prix croissant</option>
              <option value="desc">Prix décroissant</option>
            </select>
          </label>
        </div>
        <div class="cat-intro" data-cat-intro hidden></div>
        <div class="product-grid" data-products aria-live="polite"></div>
        <div class="shop-more"><button class="btn btn-ghost" type="button" data-shop-more hidden>Voir plus de créations</button></div>
        <p class="shop-note reveal"><svg><use href="#i-info"/></svg> Ajoutez vos coups de cœur à votre sélection, écrivez votre carte de vœux, puis réglez en toute sécurité par carte bancaire&nbsp;: retrait à l’atelier ou livraison, au choix.</p>

        <div class="why-price reveal">
          <div class="why-photo"><img src="<?php echo esc_url( FC_ASSETS ); ?>assets/gallery/g034-s.webp" alt="Deux fleurs à l’unité, chacune dans sa pochette transparente fermée d’un nœud rose" width="480" height="640" loading="lazy" decoding="async"></div>
          <div class="why-copy">
            <p class="eyebrow">Le prix d’une fleur</p>
            <h3>Une fleur à <span data-unit-price>8&nbsp;€</span>, <em>c’est…</em></h3>
            <ul class="why-list">
              <li><span class="why-ic"><svg><use href="#i-clock"/></svg></span><div><strong>Du temps</strong><p>Chaque pétale est plié, torsadé et ajusté à la main.</p></div></li>
              <li><span class="why-ic"><svg class="ic-wide"><use href="#i-chenille"/></svg></span><div><strong>Des fils chenille</strong><p>Choisis pour leur qualité et leur durabilité.</p></div></li>
              <li><span class="why-ic"><svg><use href="#i-stem"/></svg></span><div><strong>Une tige de fer</strong><p>Pour que chaque fleur se tienne bien droite.</p></div></li>
              <li><span class="why-ic"><svg><use href="#i-tape"/></svg></span><div><strong>Du scotch de masquage</strong><p>Pour assembler et habiller la tige.</p></div></li>
              <li><span class="why-ic"><svg><use href="#i-drop"/></svg></span><div><strong>De la colle</strong><p>Pour que chaque détail tienne bien, longtemps.</p></div></li>
              <li><span class="why-ic"><svg><use href="#i-brush"/></svg></span><div><strong>Du maquillage</strong><p>Pour donner aux pétales leurs douces nuances.</p></div></li>
              <li><span class="why-ic"><svg><use href="#i-gift"/></svg></span><div><strong>Un emballage</strong><p>Une pochette transparente, fermée d’un joli nœud.</p></div></li>
              <li class="is-love"><span class="why-ic"><svg><use href="#i-heart"/></svg></span><div><strong>Et plein d’amour</strong><p>Chaque fleur est faite avec le cœur.</p></div></li>
            </ul>
            <p class="why-card"><svg><use href="#i-mail"/></svg> Et la carte de vœux est offerte, avec le message de votre choix.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- ============================== VOTRE BOUQUET ============================== -->
    <section class="section builder" id="bouquet" aria-labelledby="builder-title">
      <div class="container">
        <div class="builder-panel">
          <div class="section-head center">
            <p class="eyebrow reveal">Votre bouquet à vous</p>
            <h2 id="builder-title" class="reveal" style="--i:1">Composez le bouquet <em>de vos rêves</em></h2>
            <p class="section-sub reveal" style="--i:2">Choisissez vos fleurs et leurs couleurs, puis écrivez votre carte de vœux&nbsp;: elle est offerte. Je façonne votre bouquet à la main et je l’emballe dans une pochette transparente fermée d’un nœud.</p>
          </div>

          <div class="builder-grid">
            <div class="builder-preview">
              <div class="preview-card" data-preview>
                <svg class="fc-stage" data-stage role="img" aria-label="Aperçu de votre bouquet"></svg>
                <p class="preview-empty">Votre bouquet prendra forme ici…<br>Ajoutez une première fleur&nbsp;!</p>
                <div class="preview-meta"><span data-b-count>0 fleur</span><span class="sep"></span><strong data-b-price>0&nbsp;€</strong></div>
              </div>
              <div class="preview-actions">
                <button class="btn btn-soft btn-sm" type="button" data-b-surprise><svg><use href="#i-sparkle"/></svg> Surprise</button>
                <button class="btn btn-soft btn-sm" type="button" data-b-undo><svg><use href="#i-undo"/></svg> Retirer</button>
                <button class="btn btn-soft btn-sm" type="button" data-b-reset><svg><use href="#i-refresh"/></svg> Recommencer</button>
                <button class="btn btn-soft btn-sm" type="button" data-b-share><svg><use href="#i-link"/></svg> Partager</button>
              </div>
            </div>

            <div class="builder-controls">
              <div class="b-step">
                <h3><span class="b-num">1</span> Choisissez une couleur <small data-b-color-name></small></h3>
                <div class="swatches" role="radiogroup" aria-label="Couleur des fleurs" data-b-colors></div>
              </div>
              <div class="b-step">
                <h3><span class="b-num">2</span> Ajoutez vos fleurs <small><span data-b-count-max>0</span></small></h3>
                <div class="flower-picker" data-b-flowers></div>
                <div class="b-chips" data-b-chips aria-label="Fleurs de votre bouquet"></div>
              </div>
              <div class="b-step">
                <h3><span class="b-num">3</span> Votre carte de vœux <small class="b-free">offerte</small></h3>
                <p class="b-hint">Votre petit mot apparaît sur la carte, à côté du bouquet. Tout est facultatif.</p>
                <div data-b-card></div>
              </div>
              <div class="b-summary">
                <dl>
                  <div><dt>Fleurs</dt><dd data-b-count-2>0</dd></div>
                  <div><dt>Emballage</dt><dd data-pack>Pochette transparente et nœud</dd></div>
                  <div><dt>Carte de vœux</dt><dd data-b-card-state>Offerte</dd></div>
                  <div class="total"><dt>Prix</dt><dd data-b-price-2>0&nbsp;€</dd></div>
                </dl>
                <button class="btn btn-primary btn-block" type="button" data-b-add><svg><use href="#i-bag"/></svg> Ajouter à ma sélection</button>
                <p class="tiny"><span data-unit-price>8&nbsp;€</span> par fleur, le feuillage est offert. Le fil chenille peut varier légèrement d’une teinte à l’autre&nbsp;: c’est tout le charme du fait main.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ============================== OCCASIONS ============================== -->
    <section class="section occasions" id="occasions" aria-labelledby="occ-title">
      <div class="container">
        <div class="section-head center">
          <p class="eyebrow reveal">Pour chaque moment</p>
          <h2 id="occ-title" class="reveal" style="--i:1">Des fleurs <em>pour chaque occasion</em></h2>
          <p class="section-sub reveal" style="--i:2">Choisissez une occasion&nbsp;: je vous propose une composition à ajuster à votre goût, ou une création adaptée.</p>
        </div>
        <div class="occasion-grid" data-occasions></div>
      </div>
    </section>

    <!-- ============================== LIVRAISON & RETRAIT ============================== -->
    <section class="section delivery" id="livraison" aria-labelledby="delivery-title">
      <div class="container">
        <div class="delivery-panel reveal">
          <div class="delivery-intro">
            <p class="eyebrow">Livraison &amp; retrait</p>
            <h2 id="delivery-title">Depuis mon atelier <em>des Ardennes</em></h2>
          </div>
          <ul class="delivery-list">
            <li><span class="ci"><svg><use href="#i-pin"/></svg></span><div><strong>Retrait à l’atelier</strong><p>Venez chercher votre création directement à l’atelier, à <span data-city>Signy-l’Abbaye</span>. C’est gratuit.</p></div></li>
            <li><span class="ci"><svg><use href="#i-truck"/></svg></span><div><strong>Livraison</strong><p data-delivery>Livraison&nbsp;: 5&nbsp;€ jusqu’à 15&nbsp;km, 10&nbsp;€ jusqu’à 25&nbsp;km autour de Signy-l’Abbaye. Au-delà, on en parle ensemble.</p></div></li>
            <li><span class="ci"><svg><use href="#i-gift"/></svg></span><div><strong>Emballage &amp; carte offerte</strong><p>Chaque création est emballée dans une pochette transparente fermée d’un nœud, avec sa carte de vœux personnalisée, offerte.</p></div></li>
          </ul>
        </div>
      </div>
    </section>

    <!-- ============================== AVIS (affichés seulement s'il y en a) ============================== -->
    <section class="section reviews" id="avis" aria-labelledby="reviews-title" hidden>
      <div class="container">
        <div class="section-head center">
          <p class="eyebrow">Mots doux</p>
          <h2 id="reviews-title">Ils ont reçu <em>un peu de douceur</em></h2>
        </div>
        <div class="review-grid" data-reviews></div>
      </div>
    </section>

    <!-- ============================== INSTAGRAM ============================== -->
    <section class="section insta" id="instagram" aria-labelledby="insta-title">
      <div class="container">
        <div class="insta-head">
          <div>
            <p class="eyebrow reveal">Sur les réseaux</p>
            <h2 id="insta-title" class="reveal" style="--i:1"><a data-ig data-ig-handle href="<?php echo esc_url( fc_instagram_url() ); ?>" target="_blank" rel="noopener">@<?php echo esc_html( fc_setting( 'instagram', 'flore_et_chenilles' ) ); ?></a></h2>
            <p class="section-sub reveal" style="--i:2">Nouveautés, coulisses de l’atelier et créations sur-mesure&nbsp;: retrouvez-moi au quotidien.</p>
          </div>
          <div class="insta-actions reveal" style="--i:3">
            <a class="btn btn-primary" data-ig href="<?php echo esc_url( fc_instagram_url() ); ?>" target="_blank" rel="noopener"><svg><use href="#i-instagram"/></svg> Instagram</a>
            <a class="btn btn-ghost" data-fb <?php fc_facebook_attrs(); ?> target="_blank" rel="noopener"><svg><use href="#i-facebook"/></svg> Facebook</a>
          </div>
        </div>
        <?php if ( fc_use_smash_balloon() ) : ?><div class="insta-feed"><?php echo do_shortcode( '[instagram-feed]' ); ?></div><?php else : ?><div class="insta-grid" data-insta></div><?php endif; ?>
      </div>
    </section>

    <!-- ============================== FAQ ============================== -->
    <section class="section faq" id="faq" aria-labelledby="faq-title">
      <div class="container faq-grid">
        <div class="faq-intro">
          <p class="eyebrow reveal">Questions fréquentes</p>
          <h2 id="faq-title" class="reveal" style="--i:1">Tout ce que vous <em>aimeriez savoir</em></h2>
          <p class="section-sub reveal" style="--i:2">Une autre question&#8239;? Écrivez-moi, j’adore parler fleurs.</p>
          <a class="btn btn-ghost reveal" style="--i:3" href="#contact">M’écrire <svg><use href="#i-arrow"/></svg></a>
        </div>
        <div class="faq-list">
          <details class="faq-item reveal" style="--i:0">
            <summary>Qu’est-ce qu’une fleur en fil chenille&#8239;?<span class="faq-ic" aria-hidden="true"></span></summary>
            <div class="faq-a"><p>Le fil chenille, que l’on appelle aussi cure-pipe, est un fil tout doux et légèrement duveteux. Je le plie et le torsade à la main pour former pétales, cœurs et feuillages. Je sélectionne mes fils pour leur qualité et leur durabilité&nbsp;: la fleur garde sa forme et ses couleurs, sans eau ni entretien.</p></div>
          </details>
          <details class="faq-item reveal" style="--i:1">
            <summary>Combien coûte une création&#8239;?<span class="faq-ic" aria-hidden="true"></span></summary>
            <div class="faq-a"><p>Une fleur à l’unité coûte <span data-unit-price>8&nbsp;€</span>. Une fleur, c’est du temps (chaque pétale est façonné à la main), des fils chenille sélectionnés pour leur qualité, une tige de fer, du scotch de masquage, de la colle, du maquillage pour les nuances des pétales et un emballage (une pochette transparente fermée d’un nœud)… et plein d’amour.</p><p>Pour un bouquet, c’est simple&nbsp;: <span data-unit-price>8&nbsp;€</span> par fleur, le feuillage est offert. Le vase est offert avec les bouquets présentés en vase, et le petit pot avec les petites fleurs en pot. Sur demande, je peux aussi fixer une fleur à l’intérieur d’un bocal transparent, pour 5&nbsp;€ de plus&nbsp;: protégée de la pluie et du vent, elle fleurit avec douceur la sépulture d’un être cher.</p></div>
          </details>
          <details class="faq-item reveal" style="--i:2">
            <summary>Puis-je choisir mes couleurs&#8239;?<span class="faq-ic" aria-hidden="true"></span></summary>
            <div class="faq-a"><p>Bien sûr&nbsp;! Composez votre bouquet fleur par fleur dans «&nbsp;Votre bouquet à vous&nbsp;», ou parlez-moi de vos idées&nbsp;: les couleurs de votre salon, de votre chambre ou de votre mariage, on peut essayer ensemble.</p></div>
          </details>
          <details class="faq-item reveal" style="--i:3">
            <summary>Proposez-vous la livraison&#8239;?<span class="faq-ic" aria-hidden="true"></span></summary>
            <div class="faq-a"><p data-delivery>Livraison&nbsp;: 5&nbsp;€ jusqu’à 15&nbsp;km, 10&nbsp;€ jusqu’à 25&nbsp;km autour de Signy-l’Abbaye. Au-delà, on en parle ensemble.</p><p>Vous pouvez aussi venir chercher gratuitement votre création à l’atelier, à Signy-l’Abbaye.</p></div>
          </details>
          <details class="faq-item reveal" style="--i:4">
            <summary>Comment mes fleurs sont-elles emballées&#8239;?<span class="faq-ic" aria-hidden="true"></span></summary>
            <div class="faq-a"><p>Toutes mes créations sont emballées dans une pochette transparente, fermée d’un joli nœud. J’y ajoute une carte de vœux, offerte&nbsp;: écrivez votre petit mot au moment de la commande, je le glisse avec votre création.</p></div>
          </details>
          <details class="faq-item reveal" style="--i:5">
            <summary>Proposez-vous des fleurs pour fleurir une sépulture&#8239;?<span class="faq-ic" aria-hidden="true"></span></summary>
            <div class="faq-a"><p>Oui. Pour honorer la mémoire d’un être cher, je fixe une fleur à l’intérieur d’un bocal transparent&nbsp;: protégée de la pluie et du vent, elle reste belle au fil des saisons, sans aucun entretien. Le bocal est à 5&nbsp;€ de plus que la fleur. Parlez-moi de vos souhaits, en toute simplicité.</p></div>
          </details>
          <details class="faq-item reveal" style="--i:6">
            <summary>Combien de temps faut-il pour réaliser ma commande&#8239;?<span class="faq-ic" aria-hidden="true"></span></summary>
            <div class="faq-a"><p>Chaque création est façonnée à la main, à la commande. Le délai dépend de la composition&nbsp;: je vous l’indique juste après votre commande. Une création unique est déjà prête. Pour une date précise, prévenez-moi le plus tôt possible.</p></div>
          </details>
          <details class="faq-item reveal" style="--i:7">
            <summary>Comment se passe le paiement&#8239;?<span class="faq-ic" aria-hidden="true"></span></summary>
            <div class="faq-a"><p>Le paiement se fait en ligne, au moment de la commande, par carte bancaire, en toute sécurité grâce à myPOS&nbsp;: je n’ai jamais accès à vos données bancaires. Vous choisissez ensuite le retrait à l’atelier ou la livraison, et je vous écris pour convenir du jour.</p></div>
          </details>
          <details class="faq-item reveal" style="--i:8">
            <summary>Faites-vous des créations pour les évènements&#8239;?<span class="faq-ic" aria-hidden="true"></span></summary>
            <div class="faq-a"><p>Avec plaisir&nbsp;: bouquets, centres de table, décorations pour un mariage, un baptême ou un anniversaire… Décrivez-moi votre projet via le formulaire de contact.</p></div>
          </details>
        </div>
      </div>
    </section>

    <!-- ============================== CONTACT ============================== -->
    <section class="section contact" id="contact" aria-labelledby="contact-title">
      <div class="container">
        <div class="contact-panel">
          <div class="contact-copy">
            <p class="eyebrow reveal">Contact</p>
            <h2 id="contact-title" class="reveal" style="--i:1">Écrivons ensemble <em>une jolie histoire</em></h2>
            <p class="section-sub reveal" style="--i:2">Une commande, un bouquet sur-mesure, un évènement à fleurir&#8239;? Laissez-moi un message&nbsp;: je vous réponds avec plaisir.</p>
            <ul class="contact-list">
              <li class="reveal" style="--i:3"><span class="ci"><svg><use href="#i-instagram"/></svg></span><div><strong>Instagram</strong><a data-ig data-ig-handle href="<?php echo esc_url( fc_instagram_url() ); ?>" target="_blank" rel="noopener">@<?php echo esc_html( fc_setting( 'instagram', 'flore_et_chenilles' ) ); ?></a></div></li>
              <li class="reveal" style="--i:4" data-fb-row hidden><span class="ci"><svg><use href="#i-facebook"/></svg></span><div><strong>Facebook</strong><a data-fb href="#contact" target="_blank" rel="noopener">Flore &amp; Chenilles</a></div></li>
              <li class="reveal" style="--i:5"><span class="ci"><svg><use href="#i-chat"/></svg></span><div><strong>Message privé</strong><a data-ig-dm href="https://ig.me/m/<?php echo rawurlencode( fc_setting( 'instagram', 'flore_et_chenilles' ) ); ?>" target="_blank" rel="noopener">Écrire sur Instagram</a></div></li>
              <li class="reveal" style="--i:6"><span class="ci"><svg><use href="#i-pin"/></svg></span><div><strong>Atelier</strong><span class="ci-text"><span data-city>Signy-l’Abbaye</span>, Ardennes</span></div></li>
              <li class="reveal" style="--i:7" data-email-row hidden><span class="ci"><svg><use href="#i-mail"/></svg></span><div><strong>E-mail</strong><a data-email href="#contact"></a></div></li>
            </ul>
          </div>

          <form class="contact-form reveal" style="--i:2" data-contact-form novalidate>
            <div class="field-row">
              <label class="field"><span>Prénom &amp; nom</span><input id="c-name" name="name" type="text" autocomplete="name" required></label>
              <label class="field"><span>E-mail</span><input id="c-email" name="email" type="email" autocomplete="email" inputmode="email" required></label>
            </div>
            <div class="field-row">
              <label class="field"><span>Téléphone <small>(facultatif)</small></span><input id="c-phone" name="phone" type="tel" autocomplete="tel"></label>
              <label class="field"><span>Date souhaitée <small>(facultatif)</small></span><input id="c-date" name="date" type="date"></label>
            </div>
            <label class="field"><span>Sujet</span>
              <select id="c-subject" name="subject">
                <option>Une commande</option>
                <option>Un bouquet sur mesure</option>
                <option>Mariage &amp; événements</option>
                <option>Une fleur souvenir en bocal</option>
                <option>Une question</option>
              </select>
            </label>
            <label class="field"><span>Votre message</span><textarea id="c-message" name="message" rows="5" required placeholder="Racontez-moi votre envie…"></textarea></label>
            <label class="hp" aria-hidden="true">Ne pas remplir<input type="text" name="_honey" tabindex="-1" autocomplete="off"></label>
            <div class="form-actions" data-form-actions></div>
            <div class="send-alert" data-send-alert role="alert" hidden></div>
            <p class="form-note">Votre message m’arrive directement par e-mail et je vous réponds au plus vite. Vos coordonnées servent uniquement à vous répondre.</p>
          </form>
        </div>
      </div>
    </section>
  </main>
