<?php
/* Généré par tools/wordpress/build.js à partir de index.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
?>
<!-- ============================== MA SÉLECTION ============================== -->
  <div class="drawer" id="cart" role="dialog" aria-modal="true" aria-labelledby="cart-title" aria-hidden="true">
    <div class="drawer-backdrop" data-close></div>
    <aside class="drawer-panel">
      <header class="drawer-head">
        <h2 id="cart-title">Ma sélection</h2>
        <button class="icon-btn" type="button" data-close aria-label="Fermer ma sélection"><svg><use href="#i-close"/></svg></button>
      </header>
      <div class="drawer-body" data-cart-items></div>
      <footer class="drawer-foot" data-cart-foot>
        <div class="cart-promo" data-cart-promo hidden></div>
        <div class="cart-total"><span>Total</span><strong data-cart-total>0 €</strong></div>
        <p class="tiny">Votre carte de vœux est offerte&nbsp;: vous l’écrirez à l’étape suivante. Paiement sécurisé par carte bancaire.</p>
        <button class="btn btn-primary btn-block" type="button" data-checkout>Commander <svg><use href="#i-arrow"/></svg></button>
      </footer>
    </aside>
  </div>

  <!-- ============================== FENÊTRE ============================== -->
  <div class="modal" id="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" aria-hidden="true">
    <div class="modal-backdrop" data-close></div>
    <div class="modal-panel">
      <button class="icon-btn modal-close" type="button" data-close aria-label="Fermer"><svg><use href="#i-close"/></svg></button>
      <div class="modal-content" data-modal-content></div>
    </div>
  </div>

  <div class="toast" role="status" aria-live="polite"></div>

  <noscript><p class="noscript">Activez JavaScript pour profiter des créations et du compositeur de bouquets.</p></noscript>
