/* Contenu du site (fleurs, couleurs, occasions, textes). Les créations viennent de la boutique WooCommerce. */
window.SITE = {
 "brand": {
  "name": "Flore & Chenilles",
  "instagram": "flore_et_chenilles",
  "logo": "assets/photos/logo.jpg",
  "city": "Signy-l’Abbaye",
  "region": "Ardennes"
 },
 "contact": {
  "email": "floreetchenilles@gmail.com",
  "showEmail": true,
  "facebook": "",
  "formEndpoint": ""
 },
 "unitPrice": 8,
 "promo": {
  "label": "Offre de lancement",
  "percent": 10,
  "from": "2026-11-04",
  "until": "2027-01-04"
 },
 "critters": true,
 "jar": {
  "price": 5,
  "label": "Dans un bocal transparent",
  "desc": "Je fixe la fleur à l’intérieur du bocal : protégée de la pluie et du vent, elle traverse les saisons. Une douce attention pour fleurir la sépulture d’un être cher."
 },
 "packaging": "Pochette transparente et nœud",
 "delivery": {
  "zones": [
   {
    "upToKm": 15,
    "price": 5
   },
   {
    "upToKm": 25,
    "price": 10
   }
  ]
 },
 "card": {
  "maxLength": 160,
  "suggestions": [
   "Joyeux anniversaire !",
   "Merci pour tout",
   "Félicitations !",
   "Bienvenue, petit cœur",
   "Avec tout mon amour",
   "Bonne fête, maman",
   "Merci, maîtresse !",
   "Pensées affectueuses"
  ]
 },
 "colors": {
  "blanc": {
   "name": "Blanc",
   "hex": "#FBF6F1"
  },
  "jaune": {
   "name": "Jaune",
   "hex": "#F7D25E"
  },
  "orange": {
   "name": "Orange doux",
   "hex": "#F5B07D"
  },
  "rose": {
   "name": "Rose",
   "hex": "#F4ADC5"
  },
  "fuchsia": {
   "name": "Fuchsia",
   "hex": "#E26DA6"
  },
  "rouge": {
   "name": "Rouge",
   "hex": "#D9455F"
  },
  "bordeaux": {
   "name": "Bordeaux",
   "hex": "#A3365D"
  },
  "mauve": {
   "name": "Mauve",
   "hex": "#C8A0E2"
  },
  "lavande": {
   "name": "Lavande",
   "hex": "#B3B0EC"
  },
  "ciel": {
   "name": "Bleu ciel",
   "hex": "#A8D3F0"
  },
  "bleu": {
   "name": "Bleu",
   "hex": "#6E9DE6"
  },
  "turquoise": {
   "name": "Turquoise",
   "hex": "#8ED6D0"
  },
  "sauge": {
   "name": "Vert feuillage",
   "hex": "#A9C3A2",
   "hidden": true
  },
  "tournesol": {
   "name": "Jaune tournesol",
   "hex": "#F5C451",
   "hidden": true
  }
 },
 "pots": {
  "terracotta": {
   "name": "Terracotta",
   "hex": "#EDC3AE"
  },
  "lilas": {
   "name": "Lilas",
   "hex": "#D8CCEE"
  }
 },
 "flowers": {
  "lys": {
   "name": "Lys",
   "plural": "Lys",
   "desc": "Grandes étoiles aux étamines dorées."
  },
  "arum": {
   "name": "Arum",
   "plural": "Arums",
   "desc": "Un cornet élégant."
  },
  "pavot": {
   "name": "Pavot",
   "plural": "Pavots",
   "desc": "Quatre grands pétales et un cœur sombre."
  },
  "gerbera": {
   "name": "Gerbera",
   "plural": "Gerberas",
   "desc": "Tout doux, plein de pétales."
  },
  "rose": {
   "name": "Rose",
   "plural": "Roses",
   "desc": "Une rose délicate, enroulée à la main."
  },
  "tulipe": {
   "name": "Tulipe",
   "plural": "Tulipes",
   "desc": "Une tulipe lumineuse."
  },
  "hortensia": {
   "name": "Hortensia",
   "plural": "Hortensias",
   "desc": "Un nuage de petites fleurs."
  },
  "tournesol": {
   "name": "Tournesol",
   "plural": "Tournesols",
   "desc": "Un soleil au milieu du bouquet.",
   "fixedColor": "tournesol"
  },
  "jonquille": {
   "name": "Jonquille",
   "plural": "Jonquilles",
   "desc": "Le printemps toute l’année."
  },
  "eucalyptus": {
   "name": "Feuillage",
   "plural": "Feuillages",
   "desc": "Pour habiller le bouquet (offert).",
   "fixedColor": "sauge",
   "foliage": true
  }
 },
 "builder": {
  "maxFlowers": 20,
  "start": {
   "color": "mauve",
   "card": {
    "to": "",
    "msg": "Pour toi, avec douceur",
    "from": ""
   },
   "flowers": [
    [
     "lys",
     "mauve"
    ],
    [
     "hortensia",
     "mauve"
    ],
    [
     "pavot",
     "mauve"
    ],
    [
     "pavot",
     "lavande"
    ],
    [
     "hortensia",
     "lavande"
    ],
    [
     "pavot",
     "fuchsia"
    ],
    [
     "arum",
     "fuchsia"
    ],
    [
     "eucalyptus"
    ],
    [
     "eucalyptus"
    ]
   ]
  },
  "palettes": [
   {
    "colors": [
     "mauve",
     "lavande",
     "fuchsia"
    ]
   },
   {
    "colors": [
     "blanc",
     "jaune"
    ]
   },
   {
    "colors": [
     "bordeaux",
     "rose"
    ]
   },
   {
    "colors": [
     "ciel",
     "rose",
     "jaune"
    ]
   },
   {
    "colors": [
     "ciel",
     "bleu",
     "lavande"
    ]
   },
   {
    "colors": [
     "fuchsia",
     "turquoise",
     "jaune",
     "orange"
    ]
   },
   {
    "colors": [
     "rouge",
     "orange",
     "jaune"
    ]
   }
  ]
 },
 "categories": [
  {
   "id": "all",
   "name": "Tout"
  },
  {
   "id": "bouquets",
   "name": "Bouquets",
   "blurb": "Un bouquet de fleurs éternelles, façonné à la main dans mon atelier."
  },
  {
   "id": "unite",
   "name": "Fleurs à l’unité",
   "blurb": "Une fleur éternelle façonnée à la main, emballée et prête à offrir.",
   "intro": "Une rose délicate, un pavot mignon, un gerbera tout doux, un joli lys, une tulipe lumineuse… Chaque fleur est emballée dans sa pochette transparente avec un nœud, et sa carte de vœux est offerte. Sur demande, je la fixe à l’intérieur d’un bocal transparent : protégée de la pluie et du vent, elle fleurira avec douceur la sépulture d’un être cher."
  },
  {
   "id": "deco",
   "name": "Déco & cadeaux",
   "blurb": "Une petite douceur fleurie, faite main, pour la maison ou pour offrir."
  }
 ],
 "products": [],
 "occasions": [
  {
   "id": "anniversaire",
   "title": "Anniversaire",
   "text": "Un bouquet qui durera bien plus longtemps que les bougies.",
   "bg": "#FBE6EA",
   "preset": {
    "message": "Joyeux anniversaire !",
    "flowers": [
     [
      "gerbera",
      "rose"
     ],
     [
      "rose",
      "fuchsia"
     ],
     [
      "lys",
      "rose"
     ],
     [
      "tulipe",
      "jaune"
     ],
     [
      "pavot",
      "orange"
     ],
     [
      "eucalyptus"
     ]
    ]
   }
  },
  {
   "id": "naissance",
   "title": "Naissance",
   "text": "Tout doux et sans pollen : parfait pour une chambre de bébé.",
   "bg": "#E3EDF8",
   "preset": {
    "message": "Bienvenue, petit cœur",
    "flowers": [
     [
      "hortensia",
      "ciel"
     ],
     [
      "tulipe",
      "blanc"
     ],
     [
      "rose",
      "ciel"
     ],
     [
      "gerbera",
      "blanc"
     ],
     [
      "eucalyptus"
     ]
    ]
   }
  },
  {
   "id": "evenements",
   "title": "Mariage & évènements",
   "text": "Bouquets, centres de table, décorations : je fleuris vos évènements sur-mesure.",
   "bg": "#F5EFE8",
   "preset": {
    "message": "Pour la vie",
    "flowers": [
     [
      "arum",
      "blanc"
     ],
     [
      "lys",
      "blanc"
     ],
     [
      "rose",
      "blanc"
     ],
     [
      "hortensia",
      "blanc"
     ],
     [
      "gerbera",
      "rose"
     ],
     [
      "eucalyptus"
     ],
     [
      "eucalyptus"
     ]
    ]
   }
  },
  {
   "id": "maitresse",
   "title": "Merci la maîtresse",
   "text": "Une fleur éternelle pour remercier la maîtresse, le maître ou l’ATSEM : {prix} la fleur, avec sa carte offerte.",
   "bg": "#F1E9F8",
   "cat": "unite",
   "preset": {
    "message": "Merci pour cette belle année",
    "flowers": [
     [
      "lys",
      "rose"
     ]
    ]
   }
  },
  {
   "id": "souvenir",
   "title": "En souvenir",
   "text": "Une fleur fixée à l’intérieur d’un bocal transparent, protégée de la pluie et du vent, pour fleurir avec délicatesse la sépulture d’un être cher.",
   "bg": "#EDF0F2",
   "cat": "unite",
   "preset": {
    "container": "bocal",
    "flowers": [
     [
      "rose",
      "blanc"
     ]
    ]
   }
  },
  {
   "id": "merci",
   "title": "Juste parce que",
   "text": "Les plus jolis bouquets n’attendent pas d’occasion.",
   "bg": "#FBEEDF",
   "preset": {
    "message": "Juste parce que",
    "flowers": [
     [
      "tournesol"
     ],
     [
      "pavot",
      "orange"
     ],
     [
      "gerbera",
      "jaune"
     ],
     [
      "tulipe",
      "jaune"
     ],
     [
      "eucalyptus"
     ]
    ]
   }
  }
 ],
 "hero": {
  "slides": [
   "pastel",
   "centre-de-table",
   "amethyste",
   "coquelicots",
   "sunny",
   "muguet"
  ],
  "featured": "bonsai"
 },
 "instagram": {
  "feedUrl": "",
  "photos": [
   {
    "src": "assets/photos/insta-hortensias.jpg",
    "alt": "Hortensias bleus et lilas",
    "url": "https://www.instagram.com/p/DZU2kcKAtXf/"
   },
   {
    "src": "assets/photos/insta-tournesol.jpg",
    "alt": "Tournesol et petites fleurs mauves",
    "url": "https://www.instagram.com/p/Da3c-dyjutu/"
   },
   {
    "src": "assets/photos/insta-odile.jpg",
    "alt": "Bouquet bleu et violet réalisé sur commande",
    "url": "https://www.instagram.com/p/DZsDjVbghCY/"
   },
   {
    "src": "assets/photos/insta-tulipes.jpg",
    "alt": "Tulipes bleue, rose et jaune",
    "url": "https://www.instagram.com/p/DZW6_7iOtcA/"
   },
   {
    "src": "assets/photos/insta-tournesol-2.jpg",
    "alt": "Tournesol en fil chenille",
    "url": "https://www.instagram.com/p/Da3c-dyjutu/"
   },
   {
    "src": "assets/photos/insta-theiere.jpg",
    "alt": "Théière de dînette fleurie",
    "url": "https://www.instagram.com/p/Da5WBcjAoWX/"
   }
  ]
 },
 "reviews": []
};
